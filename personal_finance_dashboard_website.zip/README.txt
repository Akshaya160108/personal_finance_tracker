# Personal Finance Data Analysis Dashboard

Open `index.html` in a modern browser.

Features:
- CSV / XLSX / XLS upload
- Income, expenses, savings and investment KPIs
- Monthly and year-wise charts
- Spending category analysis
- Essential vs discretionary spending
- Savings goal analysis
- Financial stress analysis
- Budget performance
- Filters and data preview

The dashboard processes uploaded files in the browser. It uses Chart.js for charts and SheetJS for spreadsheet import.
